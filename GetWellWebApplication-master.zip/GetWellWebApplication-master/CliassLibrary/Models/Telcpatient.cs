﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CliassLibrary.Models;

namespace CliassLibrary.Models
{
    public class Telcpatient
    {
        public patient patient = new patient();
        public teleconsultation teleconsultation = new teleconsultation();
    }
}
